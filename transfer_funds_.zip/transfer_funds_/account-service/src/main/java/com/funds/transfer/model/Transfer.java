package com.funds.transfer.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.funds.transfer.constant.TransferStatus;

@Entity
public class Transfer implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -333631781553001682L;
	
	@Id @GeneratedValue
	private long id;
	private double amount;
	private String currency;
	@JsonProperty("origin_account")
	private String origin;
	@JsonProperty("destination_account")
	private String destination;
	private String description;
	
	@Enumerated(EnumType.STRING)
    @Column(length = 8)
	private TransferStatus status;
	
	private Date date;
	
	public Transfer() {
	}

	public TransferStatus getStatus() {
		return status;
	}

	public void setStatus(TransferStatus status) {
		this.status = status;
	}

	public Transfer(long id, double amount, String currency, String origin, String destination, String description,
			TransferStatus status, Date date) {
		this.id = id;
		this.amount = amount;
		this.currency = currency;
		this.origin = origin;
		this.destination = destination;
		this.description = description;
		this.status = status;
		this.date = date;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
