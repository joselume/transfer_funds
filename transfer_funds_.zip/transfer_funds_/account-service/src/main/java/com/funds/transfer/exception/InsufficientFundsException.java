package com.funds.transfer.exception;

public class InsufficientFundsException extends RuntimeException{

	private static final long serialVersionUID = -6792336259609607554L;
	
	public InsufficientFundsException(String message) {
		super(message);
	}

}
