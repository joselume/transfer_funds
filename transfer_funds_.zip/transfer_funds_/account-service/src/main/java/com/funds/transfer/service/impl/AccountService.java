package com.funds.transfer.service.impl;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.funds.transfer.AccountServiceApplication;
import com.funds.transfer.dto.Movement;
import com.funds.transfer.model.Account;
import com.funds.transfer.repository.AccountRepository;
import com.funds.transfer.service.IAccountService;
import com.funds.transfer.service.IMessageManager;

@Service
public class AccountService implements IAccountService {
	
	private AccountRepository accountRepository;
	private IMessageManager messageManager;
	
	public AccountService(AccountRepository accountRepository, IMessageManager messageManager) {
		this.accountRepository = accountRepository;
		this.messageManager = messageManager;
	}

	@Override
	public void withdraw(Movement movement) {
		
		Optional<Account> accountOptional = this.accountRepository.findById(movement.getAccountId());
		if (accountOptional.isPresent()) {
			Account account = accountOptional.get();
			account.setValue(account.getValue() - movement.getValue());
			if (account.getValue() >= 0) {
				accountRepository.save(account);
			} else {
				throw new RuntimeException("insufficient-funds");
			}
		} else {
			throw new RuntimeException("invalid-origin-account");
		}
	}

	@Override
	public void deposit(Movement movement) {
		Optional<Account> accountOptional = this.accountRepository.findById(movement.getAccountId());
		if (accountOptional.isPresent()) {
			Account account = accountOptional.get();
			account.setValue(account.getValue() + movement.getValue());
			accountRepository.save(account);
		} else {
			throw new RuntimeException("invalid-target-account");
		}
		
	}

	@Override
	public Double getBanlance(String accountId) {
		Double balance = 0.0;
		Optional<Account> accountOptional = this.accountRepository.findById(accountId);
		if (accountOptional.isPresent()) {
			Account account = accountOptional.get();
			balance = account.getValue();
		}
		return balance;
	}
	
	
	
	
/*
	@Override
	public void withdraw(Movement movement, long transferId) {
		
		try {
			Account account = accountRepository.findById(movement.getAccountId()).get();
			account.setValue(account.getValue() + movement.getValue());
			accountRepository.save(account);
			
		} catch (Exception  e) { // NoSuchElementException or LockTimeoutException 
			messageManager.notifyWithdrawFail(movement, transferId);
		}
		
		// Notify success to the queue
		messageManager.notifyWithdrawSuccess(movement, transferId);
	}

	@Override
	public void processDeposit(Movement movement) {
		// TODO Auto-generated method stub
		
	}*/

}
