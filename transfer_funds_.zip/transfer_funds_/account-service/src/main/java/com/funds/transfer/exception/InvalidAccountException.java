package com.funds.transfer.exception;

public class InvalidAccountException extends RuntimeException {

	private static final long serialVersionUID = -2699983841270718886L;

	public InvalidAccountException(String message) {
		super(message);
	}

}
