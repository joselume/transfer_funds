package com.funds.transfer.constant;

public enum TransferStatus {
	PENDING,
	APPROVED,
	CANCELED
}
