package com.funds.transfer.service;

import com.funds.transfer.dto.Movement;

public interface IAccountService {
	
	public void withdraw(Movement movement);
	
	public void deposit(Movement movement);
	
	public Double getBanlance(String accountId);
}
