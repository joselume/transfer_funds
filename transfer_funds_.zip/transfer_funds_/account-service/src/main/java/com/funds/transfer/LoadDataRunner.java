package com.funds.transfer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.funds.transfer.model.Account;
import com.funds.transfer.repository.AccountRepository;

@Component
public class LoadDataRunner implements ApplicationRunner {
	
	@Autowired
	private final AccountRepository repository;
	
	public LoadDataRunner(AccountRepository repository) {
		this.repository = repository;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		repository.save(new Account("2001", 5000000.00));
		repository.save(new Account("2002", 1000000.00));
		repository.save(new Account("2003", 80000.00));
		repository.save(new Account("2004", 25000.00));
	}

}
