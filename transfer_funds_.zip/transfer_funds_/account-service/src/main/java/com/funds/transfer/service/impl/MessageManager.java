package com.funds.transfer.service.impl;

import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import com.funds.transfer.AccountServiceApplication;
import com.funds.transfer.dto.Movement;
import com.funds.transfer.service.IMessageManager;

@Service
public class MessageManager implements IMessageManager {
	
	private final RabbitTemplate rabbitTemplate;
	
	public MessageManager(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
	}

	@Override
	public void notifyWithdrawSuccess(Movement movement, long transferId) {
		/*rabbitTemplate.convertAndSend(AccountServiceApplication.WITHDRAW_SUCCESS_EXCHANGE, AccountServiceApplication.WITHDRAW_SUCCESS_ROUTING_KEY, movement, msg -> {
		    msg.getMessageProperties().getHeaders().put("transfer_id", 1);      
		    return msg;
		});*/
	}

	@Override
	public void notifyWithdrawFail(Movement movement, long transferId) {
		/*rabbitTemplate.convertAndSend(AccountServiceApplication.WITHDRAW_FAIL_EXCHANGE, AccountServiceApplication.WITHDRAW_FAIL_ROUTING_KEY, movement, msg -> {
		    msg.getMessageProperties().getHeaders().put("transfer_id", 1);      
		    return msg;
		});*/
	}
}
