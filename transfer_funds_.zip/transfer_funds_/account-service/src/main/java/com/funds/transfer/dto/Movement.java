package com.funds.transfer.dto;

import java.io.Serializable;

public class Movement implements Serializable {
	
	private static final long serialVersionUID = 7302234529568785645L;
	
	private String accountId;
	private double value;
	
	public Movement() {
	}
	
	public Movement(String accountId) {
		this.accountId = accountId;
	}
	
	public Movement(String accountId, double value) {
		this.accountId = accountId;
		this.value = value;
	}
		
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
}
