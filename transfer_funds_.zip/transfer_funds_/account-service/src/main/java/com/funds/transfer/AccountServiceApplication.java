package com.funds.transfer;

import org.apache.tomcat.jni.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.funds.transfer.dto.Movement;
import com.funds.transfer.service.IAccountService;
import com.funds.transfer.util.ByteArrayObject;

@SpringBootApplication
public class AccountServiceApplication {
	private static final Logger log = LoggerFactory.getLogger(AccountServiceApplication.class);
	
	public static final String WITHDRAW_QUEUE = "withdraw_queue";
	public static final String DEPOSITE_QUEUE = "deposite_queue";
	public static final String BALANCE_QUEUE = "balance_queue";
	
	@Autowired
	IAccountService accountService;

	@RabbitListener(queues = WITHDRAW_QUEUE, concurrency = "30")
	public String receiveWithdraw(Movement movement) {
		
		String errorMessage = null;
		try {
			accountService.withdraw(movement);
		} catch (RuntimeException e) {
			errorMessage = e.getMessage();
		}
		
		return errorMessage;
	}
	
	@RabbitListener(queues = DEPOSITE_QUEUE, concurrency = "30")
	public String receiveDeposit(Movement movement) {
		String errorMessage = null;
		try {
			accountService.deposit(movement);
		} catch (RuntimeException e) {
			errorMessage = e.getMessage();
		}
		
		return errorMessage;
	}

	@RabbitListener(queues = BALANCE_QUEUE, concurrency = "30")
	public Double getBalance(String accountId) {
		return accountService.getBanlance(accountId);
	}
	
		
	public static void main(String[] args) {
		SpringApplication.run(AccountServiceApplication.class, args);
	}
}
