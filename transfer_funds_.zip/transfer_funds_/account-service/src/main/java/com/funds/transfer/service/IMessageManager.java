package com.funds.transfer.service;

import org.springframework.amqp.core.MessagePostProcessor;

import com.funds.transfer.dto.Movement;

public interface IMessageManager {
	
	public void notifyWithdrawSuccess(Movement movement, long transferId);
	
	public void notifyWithdrawFail(Movement movement, long transferId);
}
