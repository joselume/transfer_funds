package com.funds.transfer.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class ByteArrayObject <T>{
	
	private static Logger log = LoggerFactory.getLogger(ByteArrayObject.class);
	
    public byte[] toByteArray(T obj) {
        byte[] bytes = null;
        ByteArrayOutputStream bos = null;
        ObjectOutputStream oos = null;
        try {
            bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            bytes = bos.toByteArray();
        } catch(Exception e) {
        	log.debug(e.getMessage());
        }
        return bytes;
    }

    @SuppressWarnings("unchecked")
	public T toObject(byte[] bytes){
        T obj = null;
        ByteArrayInputStream bis = null;
        ObjectInputStream ois = null;
        try {
            bis = new ByteArrayInputStream(bytes);
            ois = new ObjectInputStream(bis);
            obj = (T) ois.readObject();
        } catch(Exception e) {
        	log.debug(e.getMessage());
        }
        return obj;
    }

}
