package com.funds.transfer.service;

public interface IMessageManager {
	
	public void send(String routingKey, String Message);
	// public void receive(String routingKey, String Message);

}
