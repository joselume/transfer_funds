package com.funds.transfer.service;

import com.funds.transfer.model.Transfer;

public interface ITransferService {
	
	/**
	 * Transfer funds between two accounts
	 * @param transfer information
	 * @return
	 */
	public Transfer process(Transfer transfer);
	

}
