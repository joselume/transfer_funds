package com.funds.transfer.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.funds.transfer.model.Transfer;
import com.funds.transfer.service.IMessageManager;
import com.funds.transfer.service.ITransferService;

@Service
public class TransferService implements ITransferService{

	private final IMessageManager messageManager;
	
	public TransferService(IMessageManager messageManager) {
		this.messageManager = messageManager;
	}

	@Override
	public Transfer process(Transfer transfer) {
		
		// Send a withdraw message to the queue with transfered_value + transfer_tax
		messageManager.send("foo.bar.baz", "Hello from RabbitMQ!");
		
		
		// Invoke deposit service
		
		// Add the tax to the transaction
		
		// Persist the transfer
		
		// This method should return an ResponseBody with errors and additional information
		return null;
	}

}
