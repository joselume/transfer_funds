package com.funds.transfer.service.impl;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import com.funds.transfer.TransferServiceApplication;
import com.funds.transfer.service.IMessageManager;

@Service
public class MessageManager implements IMessageManager {
	
	private final RabbitTemplate rabbitTemplate;
	
	public MessageManager(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
	}

	@Override
	public void send(String routingKey, String message) {
		rabbitTemplate.convertAndSend(TransferServiceApplication.topicExchangeName, routingKey, message);
		
//		String dequeueMessage = (String) rabbitTemplate.receiveAndConvert(TransferServiceApplication.queueName);
//		System.out.println(dequeueMessage);
	}
}
