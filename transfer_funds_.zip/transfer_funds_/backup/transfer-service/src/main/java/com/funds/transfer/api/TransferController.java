package com.funds.transfer.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.funds.transfer.model.Transfer;
import com.funds.transfer.service.ITransferService;


@RestController
public class TransferController {
	
	ITransferService transferService;

	public TransferController(ITransferService transferService) {
		this.transferService = transferService;
	}



	@PostMapping("/transfer")
	public Transfer process(@RequestBody Transfer transfer) {

		transferService.process(transfer);
		
		return new Transfer();
	}

}
