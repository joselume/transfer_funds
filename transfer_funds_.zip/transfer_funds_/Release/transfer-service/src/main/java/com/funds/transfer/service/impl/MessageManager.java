package com.funds.transfer.service.impl;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import com.funds.transfer.TransferServiceApplication;
import com.funds.transfer.dto.Movement;
import com.funds.transfer.service.IMessageManager;

@Service
public class MessageManager implements IMessageManager {
	
	private final RabbitTemplate rabbitTemplate;
	
	public MessageManager(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
	}

	@Override
	public void sendWithdrawMessage(Movement movement, long transferId) {
		/*rabbitTemplate.convertAndSend(TransferServiceApplication.WITHDRAW_EXCHANGE_NAME, TransferServiceApplication.WITHDRAW_ROUTING_KEY, movement, msg -> {
		    msg.getMessageProperties().getHeaders().put(TransferServiceApplication.TRANSFER_ID, transferId);      
		    return msg;
		});*/
	}
}
