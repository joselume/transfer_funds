package com.funds.transfer.service;

import java.util.List;

import com.funds.transfer.model.Transfer;

public interface ITransferService {
		
	public List<Double> process(Transfer transfer);
}
