package com.funds.transfer.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.funds.transfer.TransferServiceApplication;
import com.funds.transfer.dto.CurrencyConversion;
import com.funds.transfer.dto.Movement;
import com.funds.transfer.exception.BusinessRuleException;
import com.funds.transfer.model.Transfer;
import com.funds.transfer.repository.TransferRepository;
import com.funds.transfer.service.ITransferService;

@Service
public class TransferService implements ITransferService{
			
	private static final int MAX_TRANSFERS_PER_DAY = 3;
	private static final String DOLLAR_CURRENCY = "USD";
	private static final String CAD_CONVERSION_URL = "https://api.exchangeratesapi.io/latest?base=USD";
	private final Logger log = LoggerFactory.getLogger(TransferService.class);
	
	private final RabbitTemplate rabbitTemplate;
	private final TransferRepository transferRepository;
	private final RestTemplate restTemplate;
	
	public TransferService(RabbitTemplate rabbitTemplate, TransferRepository transferRepository,
			RestTemplate restTemplate) {
		this.rabbitTemplate = rabbitTemplate;
		this.transferRepository = transferRepository;
		this.restTemplate = restTemplate;
	}
		
	@Override
	public List<Double> process(Transfer transfer) {
		
		double tax = this.calculateTax(transfer.getAmount());
		
		this.validations(transfer, tax);
		
		// Withdraw
		Movement withdrawMovement = new Movement(transfer.getOrigin(), transfer.getAmount() + tax) ;
		String errorMessage = this.sendWithdrawMessage(withdrawMovement);
		if (errorMessage != null) {
			reportSingleError(errorMessage);
		}
		
		// Deposit
		errorMessage = this.sendDepositMessage(new Movement(transfer.getDestination(), transfer.getAmount()));
		if (errorMessage != null) {
			String compensastionError = sendDepositMessage(withdrawMovement);
			if (compensastionError != null) {
				log.info("Sending compensation fail notification ...");
			}
			reportSingleError(errorMessage);
		}
				
		// Save the transference
		transfer.setDate(new Date());
		transferRepository.save(transfer);
		
		return Arrays.asList(tax, getTaxCAD(tax));
	}
	
	private void validations (Transfer transfer, Double tax) {
		List<String> errors = new ArrayList<>();
		
		if(transfer.getOrigin() == null || transfer.getDestination() == null || transfer.getAmount() == null) {
			errors.add("missing-arguments");
		}
		
		Double balance = this.sendBalanceMessage(transfer.getOrigin());
		log.debug("Origin account balance: "+ balance);
		if ((balance - transfer.getAmount() - tax) < 0 ) { 
			errors.add("insufficient-funds");
		}
		
		List<Transfer> transferences = transferRepository.findAllWithCreationDateTimeAfter(transfer.getOrigin(), java.sql.Date.valueOf(LocalDate.now()));
		if (transferences.size() >= MAX_TRANSFERS_PER_DAY) {
			errors.add("limit-exceeded");
		}
		
		if (!DOLLAR_CURRENCY.equals(transfer.getCurrency())) {
			errors.add("currency-not-supported");
		}
		
		if (errors.size() > 0) {
			throw new BusinessRuleException("There are error that do not allow the transer", errors);
		}
	}
	
	private String reportSingleError (String message) {
		List<String> errors = new ArrayList<>();
		errors.add(message);
		throw new BusinessRuleException("There are error that do not allow the transer", errors);
		
	}
	
	private Double calculateTax(Double amount) {
		return (amount >= 100.00) ? amount * 0.05 : amount * 0.02; 
	}
	
	private Double getTaxCAD(Double taxUS) {
		CurrencyConversion currencyConversion = restTemplate.getForObject(CAD_CONVERSION_URL, CurrencyConversion.class);
		Double taxCAD = 0.00;
		if (currencyConversion != null && currencyConversion.getRates() != null) {
			taxCAD = taxUS / currencyConversion.getRates().getCAD(); 
		}
		log.debug("Tax in CAD: "+ taxCAD);
		return taxCAD;
		
	}
	
	private String sendWithdrawMessage(Movement movement) {
		return (String) rabbitTemplate.convertSendAndReceive(TransferServiceApplication.WITHDRAW_EXCHANGE, TransferServiceApplication.WITHDRAW_ROUTING_KEY, movement);
	}
	
	private String sendDepositMessage(Movement movement) {
		return (String) rabbitTemplate.convertSendAndReceive(TransferServiceApplication.DEPOSITE_EXCHANGE, TransferServiceApplication.DEPOSITE_ROUTING_KEY, movement); 
	}
	
	private Double sendBalanceMessage(String accountId) {
		return (Double) rabbitTemplate.convertSendAndReceive(TransferServiceApplication.BALANCE_EXCHANGE, TransferServiceApplication.BALANCE_ROUTING_KEY, accountId); 
	}
}
