package com.funds.transfer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Rate {
	@JsonProperty("CAD")
	private double CAD;

	public Rate() { }

	public Rate(double CAD) {
		this.CAD = CAD;
	}

	public double getCAD() {
		return CAD;
	}

	public void setCAD(double CAD) {
		this.CAD = CAD;
	}
}
