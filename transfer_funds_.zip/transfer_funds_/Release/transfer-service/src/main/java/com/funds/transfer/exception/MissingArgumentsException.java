package com.funds.transfer.exception;

public class MissingArgumentsException extends RuntimeException {

	private static final long serialVersionUID = 4277120761295008572L;
	
	public MissingArgumentsException (String message) {
		super(message);
	}
}
