package com.funds.transfer.dto;

public class CurrencyConversion {
	Rate rates;

	public CurrencyConversion() {}

	public CurrencyConversion(Rate rates) {
		this.rates = rates;
	}

	public Rate getRates() {
		return rates;
	}

	public void setRates(Rate rates) {
		this.rates = rates;
	}	
}
