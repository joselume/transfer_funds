package com.funds.transfer.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.funds.transfer.dto.TransferError;

@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
		
	@ExceptionHandler({BusinessRuleException.class})
	protected ResponseEntity<Object> handleTransferBadRequest(BusinessRuleException ex) {
		TransferError transferError = new TransferError(HttpStatus.BAD_REQUEST, ex.getErrors(), ex);
		return buildResponseEntity(transferError);
	}
	
	@ExceptionHandler({Throwable.class})
	protected ResponseEntity<Object> handleThrowable(Throwable ex) {
		List<String> errors = new ArrayList<>();
		errors.add(ex.getMessage());
		TransferError transferError = new TransferError(HttpStatus.BAD_REQUEST, errors, ex);
		return buildResponseEntity(transferError);
	}

   private ResponseEntity<Object> buildResponseEntity(TransferError transferError) {
       return new ResponseEntity<>(transferError, transferError.getStatus());
   }
}
