package com.funds.transfer.dto;

import java.util.List;

import org.springframework.http.HttpStatus;

public class TransferResponse {
	
	private HttpStatus status;
	private List<String> errors;
	private Double tax_collected;
	private Double CAD;
	
	public TransferResponse(HttpStatus status, List<String> errors, Double tax_collected, Double cAD) {
		this.status = status;
		this.errors = errors;
		this.tax_collected = tax_collected;
		this.CAD = cAD;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	public Double getTax_collected() {
		return tax_collected;
	}

	public void setTax_collected(Double tax_collected) {
		this.tax_collected = tax_collected;
	}

	public Double getCAD() {
		return this.CAD;
	}

	public void setCAD(Double cAD) {
		this.CAD = cAD;
	}
}
