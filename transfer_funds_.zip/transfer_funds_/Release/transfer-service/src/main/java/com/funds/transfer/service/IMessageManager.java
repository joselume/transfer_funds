package com.funds.transfer.service;

import com.funds.transfer.dto.Movement;

public interface IMessageManager {
	
	public void sendWithdrawMessage(Movement movement, long transferId);
}
