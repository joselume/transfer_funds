package com.funds.transfer.exception;

import java.util.ArrayList;
import java.util.List;

public class BusinessRuleException extends RuntimeException {

	private static final long serialVersionUID = 7352565328085041944L;
	
	private List<String> errors = new ArrayList<>();

	public BusinessRuleException(String message, List<String> errors) {
		super(message);
		this.errors = errors;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}	
}
