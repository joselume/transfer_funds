package com.funds.transfer.exception;

public class CurrencyNotSupportedException extends Exception {

	private static final long serialVersionUID = -6708315837015577139L;
	
	public CurrencyNotSupportedException(String message) {
		super(message);
	}
}
