package com.funds.transfer.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.funds.transfer.dto.Movement;
import com.funds.transfer.dto.TransferResponse;
import com.funds.transfer.model.Transfer;
import com.funds.transfer.service.ITransferService;


@RestController
public class TransferController {
	
	private final ITransferService transferService;

	public TransferController(ITransferService transferService) {
		this.transferService = transferService;
	}

	@PostMapping("/transfer")
	public TransferResponse process(@RequestBody Transfer transfer) {
	
		List<Double> taxes = transferService.process(transfer);
		
		return new TransferResponse(HttpStatus.OK, new ArrayList<String>(), taxes.get(0), taxes.get(1));	
	}
}
