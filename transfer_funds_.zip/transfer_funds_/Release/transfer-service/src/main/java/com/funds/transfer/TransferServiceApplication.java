package com.funds.transfer;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class TransferServiceApplication {

	public static final String WITHDRAW_EXCHANGE = "withdraw_exchange";
	public static final String WITHDRAW_QUEUE = "withdraw_queue";
	public static final String WITHDRAW_ROUTING_KEY = "transfer.withdraw";
	
	public static final String DEPOSITE_EXCHANGE = "deposite_exchange";
	public static final String DEPOSITE_QUEUE = "deposite_queue";
	public static final String DEPOSITE_ROUTING_KEY = "transfer.deposite";		
	
	public static final String BALANCE_EXCHANGE = "balance_exchange";
	public static final String BALANCE_QUEUE = "balance_queue";
	public static final String BALANCE_ROUTING_KEY = "transfer.balance";

	@Bean
	Queue balanceQueue () {
		return new Queue(BALANCE_QUEUE, true);
	}
	
	@Bean
	DirectExchange balanceExchange () {
		return new DirectExchange(BALANCE_EXCHANGE);
	}
	
	@Bean
	Binding balanceBinding() {
	  return BindingBuilder.bind(balanceQueue()).to(balanceExchange()).with(BALANCE_ROUTING_KEY);
	}
	
	@Bean
	Queue withdrawQueue () {
		return new Queue(WITHDRAW_QUEUE, true);
	}
	
	@Bean
	DirectExchange withdrawExchange () {
		return new DirectExchange(WITHDRAW_EXCHANGE);
	}
	
	@Bean
	Binding withdrawBinding(Queue withdrawQueue, DirectExchange withdrawExchange) {
	  return BindingBuilder.bind(withdrawQueue).to(withdrawExchange).with(WITHDRAW_ROUTING_KEY);
	}
	
	@Bean
	Queue depositeQueue () {
		return new Queue(DEPOSITE_QUEUE, true);
	}
	
	@Bean
	DirectExchange depositeExchange () {
		return new DirectExchange(DEPOSITE_EXCHANGE);
	}
	
	@Bean
	Binding depositBinding() {
	  return BindingBuilder.bind(depositeQueue()).to(depositeExchange()).with(DEPOSITE_ROUTING_KEY);
	}
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(TransferServiceApplication.class, args);
	}
	  

	/*
	public static final String WITHDRAW_EXCHANGE_NAME = "transfer-exchange";
	public static final String WITHDRAW_QUEUE_NAME = "withdraw_queue";
	public static final String WITHDRAW_ROUTING_KEY = "transfer.withdraw";
	
	public static final String TRANSFER_ID = "transfer_id";
	
	@Bean
	Queue queue() {
	  return new Queue(WITHDRAW_QUEUE_NAME, false);
	}
	
	@Bean
	TopicExchange exchange() {
	  return new TopicExchange(WITHDRAW_EXCHANGE_NAME);
	}
	
	@Bean
	Binding binding(Queue queue, TopicExchange exchange) {
	  return BindingBuilder.bind(queue).to(exchange).with(WITHDRAW_ROUTING_KEY);
	}
	
	}*/
}
